import 'package:flutter/material.dart';
import 'package:flutter_app/userdata.dart';
import 'package:flutter_app/useritem.dart';
import 'package:flutter_app/userlist.dart';

void main() {
  // UserData userIdris = UserData("Idris", 34, "idrez.mochamad@gmail.com");
  runApp(UserList());
}
