class UserData {
  String nama;
  int umur;
  String email;

  UserData(this.nama, this.umur, this.email);
}
